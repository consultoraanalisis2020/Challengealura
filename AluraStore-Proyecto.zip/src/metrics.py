
import pandas as pd
import numpy as np
from typing import Dict

EXPECTED_COLS = {
    "producto": ["producto", "product", "nombre_producto"],
    "categoria": ["categoria", "categoría", "product_category", "categoria_del_producto", "categoría del producto"],
    "precio": ["precio", "price", "valor"],
    "envio": ["envio", "envío", "costo_envio", "costo de envío", "frete", "shipping_cost"],
    "calificacion": ["calificacion", "calificación", "nota_compra", "evaluacion", "evaluación de compra", "review_score", "rating"],
    "fecha": ["fecha", "order_purchase_timestamp", "data", "date"],
    "ciudad": ["ciudad", "city"],
}

def _normalize_cols(df: pd.DataFrame) -> pd.DataFrame:
    import unicodedata
    df = df.copy()
    def _norm(s):
        s = unicodedata.normalize("NFKD", s)
        s = "".join(c for c in s if not unicodedata.combining(c))
        s = s.lower().strip().replace(" ", "_")
        return s.replace("__", "_")
    df.columns = [_norm(c) for c in df.columns]
    mapping = {}
    for std, aliases in EXPECTED_COLS.items():
        for a in aliases:
            a2 = a.lower().replace(" ", "_")
            if a2 in df.columns:
                mapping[a2] = std
    return df.rename(columns=mapping)

def compute_store_metrics(df: pd.DataFrame, store_name: str) -> Dict:
    df = _normalize_cols(df)
    for col in ["precio", "envio", "calificacion"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    total_ingresos = df["precio"].sum(skipna=True) if "precio" in df.columns else np.nan
    categoria_counts = df["categoria"].value_counts().rename_axis("categoria").to_frame("ventas") if "categoria" in df.columns else pd.DataFrame()
    calificacion_prom = df["calificacion"].mean(skipna=True) if "calificacion" in df.columns else np.nan
    prod_counts = df["producto"].value_counts() if "producto" in df.columns else pd.Series(dtype=int)
    top_prod = prod_counts.head(5)
    bottom_prod = prod_counts.tail(5) if len(prod_counts) >= 5 else prod_counts
    envio_promedio = df["envio"].mean(skipna=True) if "envio" in df.columns else np.nan
    return {
        "store": store_name,
        "total_ingresos": total_ingresos,
        "categoria_counts": categoria_counts,
        "calificacion_prom": calificacion_prom,
        "top_prod": top_prod,
        "bottom_prod": bottom_prod,
        "envio_promedio": envio_promedio,
        "df": df
    }

def efficiency_score(summary_df: pd.DataFrame) -> pd.DataFrame:
    s = summary_df.copy()
    def _norm(col, invert=False):
        vals = s[col].astype(float)
        mn, mx = vals.min(), vals.max()
        n = pd.Series(1.0, index=s.index) if mx == mn else (vals - mn) / (mx - mn)
        return (1-n) if invert else n
    s["score_ingresos"] = _norm("total_ingresos")
    s["score_calif"]    = _norm("calificacion_prom")
    s["score_envio"]    = _norm("envio_promedio", invert=True)  # menor costo = mejor
    w_ing, w_cal, w_env = 0.5, 0.3, 0.2
    s["score_total"] = w_ing*s["score_ingresos"] + w_cal*s["score_calif"] + w_env*s["score_envio"]
    return s.sort_values("score_total", ascending=False)
